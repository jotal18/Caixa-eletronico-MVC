$(document).ready(function(){

	$('.formulario').hide();

	$('.form_jquery').bind('click', function(){

		$('.formulario').toggle();

	});

});